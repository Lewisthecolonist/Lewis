Exception has occurred: SystemExit
1
  File "/workspaces/Trading-Bot2/main.py", line 40, in main
    await trading_system.start()
  File "/workspaces/Trading-Bot2/trading_system.py", line 78, in start
    market_data = await self.market_maker.update_market_data()
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/Trading-Bot2/market_maker.py", line 396, in update_market_data
    market_data = await self.get_recent_data()
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/workspaces/Trading-Bot2/market_maker.py", line 629, in get_recent_data
    ohlcv = await self.exchange.fetch_ohlcv(
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
ccxt.base.errors.ExchangeNotAvailable: kraken GET https://api.kraken.com/0/public/Assets 403 Forbidden <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
<meta name="robots" content="noindex" />
<title>One More Step</title>
<style type="text/css">body,html{height:100%;width:100%}body{background-color:#0d0c52;color:#fff;font-family:Helvetica,sans-serif;margin:0}article{display:grid;grid-template-columns:100%;grid-template-rows:auto 1fr auto;min-height:100%}footer,header{background-color:#5740d9;padding:34px 0 30px 40px}main{align-items:center;display:inline-grid;grid-template-columns:50% 50%;padding:50px 0}main>div:first-child{padding-left:30%}@media (max-width:800px){main{grid-template-columns:100%}main>div:first-child{padding:0 40px}main>div:last-child{display:none}}a{color:#fff}</style>
<meta http-equiv="refresh" content="390">
</head>
<body>
<article>
<header>
<a href="/">
<img alt="Kraken logo" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDIiIGhlaWdodD0iMzIiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0iTTIwLjk5NiAwQzkuMzk3IDAgMCA5LjEyIDAgMjAuMzY2djguNzI3QzAgMzAuNyAxLjM0MyAzMiAyLjk5NiAzMiA0LjY1IDMyIDYgMzAuNyA2IDI5LjA5M3YtOC43MjdjMC0xLjYwOCAxLjMzNy0yLjkxMSAyLjk5OC0yLjkxMSAxLjY1NSAwIDIuOTk4IDEuMzAzIDIuOTk4IDIuOTExdjguNzI3YzAgMS42MDcgMS4zNDQgMi45MDcgMi45OTkgMi45MDcgMS42NTkgMCAzLjAwMi0xLjMgMy4wMDItMi45MDd2LTguNzI3YzAtMS42MDggMS4zNDQtMi45MTEgMi45OTgtMi45MTEgMS42NjIgMCAzLjAwNiAxLjMwMyAzLjAwNiAyLjkxMXY4LjcyN2MwIDEuNjA3IDEuMzQzIDIuOTA3IDIuOTk2IDIuOTA3IDEuNjU0IDAgMi45OTgtMS4zIDIuOTk4LTIuOTA3di04LjcyN2MwLTEuNjA4IDEuMzQzLTIuOTExIDMuMDA1LTIuOTExIDEuNjU1IDAgMi45OTggMS4zMDMgMi45OTggMi45MTF2OC43MjdDMzYgMzAuNyAzNy4zNDMgMzIgMzkuMDAyIDMyIDQwLjY1NyAzMiA0MiAzMC43IDQyIDI5LjA5M3YtOC43MjdDNDIgOS4xMiAzMi41OTYgMCAyMC45OTYgMCIgZmlsbD0iI0ZGRiIgZmlsbC1ydWxlPSJldmVub2RkIi8+PC9zdmc+" /></a>
</header>
<main>
<div>
<h1>One More Step</h1>
<p>
Please complete the security check to access Kraken.com
</p>
<p>
<div class="main-wrapper" role="main"><div class="main-content"><noscript><div class="h2"><span id="challenge-error-text">Enable JavaScript and cookies to continue</span></div></noscript></div></div><script>(function(){window._cf_chl_opt={cvId: '3',cZone: "api.kraken.com",cType: 'managed',cRay: '905bb00c8ea2fba6',cH: 'rrNQqyRbYkIz0fRtH515ccm__cYBpHstizZoYXL0VpM-1737508471-1.2.1.1-47gmgqw.lAsnPotHIrCp1gS6whV5Y4dIausONZcJXvMnKE4cr..52H2vXtccC8s_',cUPMDTk: "\/0\/public\/Assets?__cf_chl_tk=7eezclmrwpPLmWHokgOdG1jPQiknUctBdI09r9hIcGY-1737508471-1.0.1.1-.DX1LdtR6503YdFnTtv7cCPtfbMezV.7Zz9V3cRNS3o",cFPWv: 'g',cITimeS: '1737508471',cTTimeMs: '1000',cMTimeMs: '390000',cTplC: 1,cTplV: 5,cTplB: 'cf',cK: "",fa: "\/0\/public\/Assets?__cf_chl_f_tk=7eezclmrwpPLmWHokgOdG1jPQiknUctBdI09r9hIcGY-1737508471-1.0.1.1-.DX1LdtR6503YdFnTtv7cCPtfbMezV.7Zz9V3cRNS3o",md: "KTlvaZc3KicS6BTbxbl3xHIH4wlBCKeSiSJvv3btQIA-1737508471-1.2.1.1-2Q326EdYfGKhp2YHtMKuVw_6rKNe7bvZSKaAWs.o8LbSJZcC7006KOGp88.8HrPm9xNzBgI6f.CuHPgataJmWTJX55Qo2FBsQtuNX5qlmiT5dlWgPhHvwQzSHl_qEEh7DIT8PgDVvLt1kUwNDpKnTeoLdJpAW_GoWrHRbU0XeAXQLdRrmFTXJ69d.lFGyTXBkEXC_TajgSMgYLK1vDocVck6C2thYF0.vmX_NrCXmRSffmmztzTqeLuhSmQiyhebZbQRt_eFi8obPBh.cHVE_u_fWIhkKUYQPDmk2QaNogExTpbUR8zVgjJRJzYONHwCoxf1SgXYTQ7KcAlpfK9W0pMC8YBfcdyP_mXulCpZT.cnDMmc2RwKplDcfl3JlIxkGmCSOVyYYcegC220JebLetCVMaq4CuNENjOmCPoy37jUhxYPhpsf8BHh6.UlQ7NrOwhDLPiwgq4f1Oi.iRACcyW542gEmD6P4MvoZ3Wiw9hKe0u2wvyLrTA9hFsnuSg9Z05sIc.L1M1J001M7sNJTNlLTG7iXMnqINEQxsBul4_l27an0kxu9LZ1v7K13HKwDleBcIzh2gdrvmFemMg_O7Zx5JfKBZYhfjxjgEzTD6QgifxIMYYxBhN_17FDXIvue938C5ijCyIZLjJM9UhBcryFS3MjCdvMIhLojn.we.7c9evDQZS8N4Us6J1cPdXwdXLIfSZawM9ZFMzQtJ3xUJUlz_8Ct80wPfc1BS66z.hNwFow_umEw5KCbE29RA15n8.Sl13EIt6laobxod2PT11ylHvKnCYt.xojy6RIYIF3eW.FR9wqeHOKuWKbTjNXwKiKi0h0FAnbc4oTeywtkw2guOEl6f44IMOgMsROD1hYnT30wc.s1FQ0JTou.kMPNI6y84UpcYlW8J5vI8bniDBy2rvDoPGHFRfUCIxm_wLAM6LXP91ZM6yuIqcn4OSz7Ar8fyLx7BG7jN6svzuXhZFMZy63FOy73cWTmrrYCRtm_wx6XBgqyBBDu9KzwuRKKfB4jmFLsRKfG0hNZdMYzy.c4n.UowQQhx.7e5sHzE_pC.KBF0LTKQk3h6QVaDliB8zZvM6XfWAofx6TH4zGP3roFIxqwvprLHJpl9C8jXEAlbJNAOrWHEU9rrMrg2bILeaa7iRV9Bm1BnEwJHt_nxvZ4KvAngBBcdfyXSXydageMxSgOWb4Mp2itL.ZeTd1dc6TJbnaGjINFZcDe7plOAE8abK7L72LNtwOE493mqhA6Vz7u6sFwwzemy5hdyp70u4VP_GhgiwL5rT39qRjmS7nlquvogRXkfS4GkUdRKrWiZpoCadXKYoE.4UtUg1VK7JeSGZhzx4fWvm.2jbU6aLIjiRWj857u61kAYVEf2zJrjMLmIdcm3lW8FKOSdLS.3AdegUnEoofxLoV8d89eCVfEsV.wR4GY0wLdJtksUDzPvQqiif.Yfhc8_5YG2M2waS2FMicvj.qOhf8rf4D.EUljHa9u48PqEm5psQZNDhaq9wzC2QdPD9PcI4geNOS8tnuBiPLHpEdwEbCaMTqSHxK5mt9Nk3xVriyrqkBBGigSk7QPydKB.fCx9pYOW1PilyeTfuewyVw1ncsdi5UHRmmCVKXkXXtIe5a1PaCs4Sg_spWPUcbvqOakVJkV048ds9R9r1HS0EoF6vQqA89zSnwiQWCg4Gz3Q.Q6WhKRdMgB9ERWrOqgZl29kC1Zzoqygd6k747cxDMUdPZuMcG305ZEgI06iaUasI0_PIDrS118lEu48GcLAyLyFUun.ZLT05O_5rXXEDchxZ9hYCsyr1evudxGsmecHrD7hR4FfPg75LMtfTWYJ_TFv52Qw43ACdEUBPCnMMy.7DQHZyzW9gJKmOY7JiNLESDuqsjdIT8ZeGfPKJDg8H3i7Sf3r_JXnhqX7HuMQVym2TAyd8smYt0W7RPSwn8E9V2kp90I.chUqcjm4V5lUEmVnFo_0rJkCy5X40BlJHyBUGzSR0hbipDAeZNtKpQH_wHsC8zpckEv4liH9gnEORlU0bzaJ_C_6lLICexFTQpV3LM7qwaMv.rHkWYgQmyHOnOtcfSLEOhp6QSxKr55A.pYHrHy15fcCosrqw.J_Z3vjI659AsQLFd_sZn1yg.GQehseqfVK94xjYOQkWxXHR42cU04rLVpul1NlvdwkmF4op52fxXRvEYYHAjQ0_HEETVgydFM.Y",mdrd: "zvNv656MErbUJWzvj9GaXbKyFjEuBqt1N_KL0zK_Rng-1737508471-1.2.1.1-VImmAH3C0RloTUBrNozNpCpteM9hqdDj4lI4df1cZHq1991uoMRbSlOuy7DxnFB_K8PaYm8qPSn7pMczBrr7hS6Mm3gdLNu4N.eTUdYYJiKQtX1U363cIqt1FMo0od7UkRTNmN.ha4Mg0deSvMD4692JwYWOZT2URpvZhqhEQjX3tKJWetG.7.ffAMctmp6RBWuhQMHSKcIxaGIsFwPbCkfV7QH7RZeJ15iCOrxD81jG_SQ.0mAQ4.KCJFKRt.iTZwmMmPn5giIUY0LareZbPM.Khs9BjtKPYwZHFkAg3gwKQv2g3eyI4oXl3Jywj_5AVmmTp60TVwIkxofrV2BLypf0NQPEIKROCqROsSUZgmd1WGOG1C9nqjoAEwf7GinqjptRXYBqwUj5egzVPJEwjX4GWgp6597pQ23R1_I7NH4CGFr8uTjAPmpdnTDZgIB4PgSsOqwjoxNs9kfK1Dz428seAargD8UpviboA.5S00rutN0nCTAA6cxoU.ivXmYS5dCqMBKUqrwVRtA0_GTsE7lu4JfcxCuoomFuBpSDHrPINtEELr.aSKTu63VjWLWasUxfJCw4baYHnHDw4.lGx7UMxWkAPHwlUyOhNzt3M.6xU32jfFKINCNcSjPRscDEWjTAXp9xDSO0JYQ1DRt5OE2lO36B7yno8yneD0mZ8nzpyKp9KP9E38e.9u9oJxUBPp93yUeUs2MZPvzWwIC3Kzqv5cVqEVgMkUh1BdkRtSEtgGLvY73XR1m3JijJNZdQDXoxVfK_MxIGZsNNJCBFflETgM7Yf08dZhmK_mGaOQsu4CKF4iohMDc09CXyXOFyAPFvb6rxR2DZqvF.Jmzbc0_F8N9pRzuALnmi8dQ47GWMZCYiaV6YDcn60yoRnMdap5ECuULmIV8CQCia2ztGy4zdbth1Fy_JtEY8e.yLrTWn9p1yc_7FHRFUGxYHXijC7FuB9C_FvYRrijRQinJVUHF0dVQuzT0AeenahKMmQxLNKO1CmBPOPZqe7w6q5KjMDhA2pQcST_Xzgvmdp8tKnD04uRhNKoHzG0jXWWF2m0F4srYtzV_HBClt3Vu4cA_iwUg307bvUNnp1xyAsKWs8RVuf33b5QblcxpjaFxRgcJ39z9i9L6LQ2BrXOqphjOuRgrERi_Tqyo5Uuny38bImkf6VRjJp0xTMwfhhw7H9sllkMvPCEzATKJBIS0G_R9UO5pGb4LBqhNxQ4lAULRVQ2tMxste6Jla62VO2S425mtdbAVD_37l1rMO7mHVJPUoyw.XvcBMivxObecYktJuXJC_rVJceaOO_l6525IYd8QMOdi59rsUsV3gzlMKYVXB_T4Dx3sefkEd1SO07KYpHbBNYevM.Gr4I7FapqALmR.1KqrXqjJDwU.31qC5yn8qiEeOeQfyFMEzgRJb7Wc5PmFSC4vZYy8WXMJn.ddCDoUNc6fHN4ZkzhCnjsJvnOpEpbfs77njGvmkNkSnTbq1H68J2RKH.fM4IJ4ggSqQ.XcJYaap268RHY678FegQB_0XxyvAJ3BTSXtH0oLl9WZkv3TIyvMlUvZNXmI5l4ToHfFrNhbxDp2Q1Fqr.2y5peETQb2b547XmF2bvSHxY3ZcugCXqm_ccps8ng0aZAMBNmP8Rh3WlG.BdmSmfU312Dqun3Y6.EcWIgqlNf2eGX_OkxnrA7S2iQWU9DvHiS72Si9fK2SbdDDvuiAivMQBF1Y5rfDqwLhbM_7uYGt7NSQXjgGeTb7RxBvrbe5whWuJMZte.OUd7Je4CcxTxQjDRxS6oUifozW33Ee39IdW9EriJWQZq4XhZb8vADKB8E_bTEbFAKHpfty4jCCtRXlZtpgpe6NOb0PkqEKVyjekEMvvMy7O1Tnuk.WZy896.NzydNoLo.uLJ8AwX4t5LqFkU8PKTjiBZE4QkG17fbynfE_x7UuRxxMiEuBgEenhUAMW.t3xmzDyponc8GR81u46bu2H7SpSy3RIaVy.eEIiK9jCqgyLxrut.pnsgVvGM8Ra1pEWw4Jz2tQD2XufqpL_ncrByZtPYO6bGPYBOgujiV7n_LseNWAOixM0Xd5eriBrAJLoNxF6iIgGUMnGdRmitupDY4EVHiKghw15eQJ7zvPCUdJgjF160Wy3bnFrGhjXbXvxwV9rMw4mDzRdqCUddOtHpEdzle6ut0dXT2wHpsOrkZOJsA7UQ6SlsnZ7Ze7Hi6.65h5k7LWOhal2m8J.A_xgmCI1BIMUSTxxP7xVfzDRyqCeyopXTiYgQA9FHSD9TbIK4NLXD4ZLzbVVKPkkPW_g0wrkaHYFUzjWW6R8gxmUy1DYgL8lftPCZN3GtIDflUfr68SE4KZqr5zbIbOdo78fg__Py8UA3kGBX.6c0O6Za00EtLMvGx6p6h7jJSU7z9_YyOY5AIe0Z5ksWFXDM0L"};var cpo = document.createElement('script');cpo.src = '/cdn-cgi/challenge-platform/h/g/orchestrate/chl_page/v1?ray=905bb00c8ea2fba6';window._cf_chl_opt.cOgUHash = location.hash === '' && location.href.indexOf('#') !== -1 ? '#' : location.hash;window._cf_chl_opt.cOgUQuery = location.search === '' && location.href.slice(0, location.href.length - window._cf_chl_opt.cOgUHash.length).indexOf('?') !== -1 ? '?' : location.search;if (window.history && window.history.replaceState) {var ogU = location.pathname + window._cf_chl_opt.cOgUQuery + window._cf_chl_opt.cOgUHash;history.replaceState(null, null, "\/0\/public\/Assets?__cf_chl_rt_tk=7eezclmrwpPLmWHokgOdG1jPQiknUctBdI09r9hIcGY-1737508471-1.0.1.1-.DX1LdtR6503YdFnTtv7cCPtfbMezV.7Zz9V3cRNS3o" + window._cf_chl_opt.cOgUHash);cpo.onload = function() {history.replaceState(null, null, ogU);}}document.getElementsByTagName('head')[0].appendChild(cpo);}());</script>
</p>
</div>
<div>
</div>
</main>
<footer>
<small>&copy; 2011 - <span id="currentYear"></span> Payward, Inc.</small>
</footer>
</article>
<script>document.getElementById("currentYear").innerHTML=(new Date).getFullYear();</script>
</body>
</html>

During handling of the above exception, another exception occurred:

  File "/workspaces/Trading-Bot2/main.py", line 47, in main
    sys.exit(1)
  File "/workspaces/Trading-Bot2/main.py", line 68, in <module>
    asyncio.run(main())
SystemExit: 1